## Tasks list

### RCC
- [X] IOP
- [ ] AHB
- [X] APB1
- [ ] APB2
- [X] CFGR (conferir)

### GPIO
- [x] traits embedded hal
- [x] pull up
- [ ] pull down
- [x] push pull
- [ ] open drain
- [ ] Afs (mudar isso)
    - [x] AF5 - PA5 TIM2_ch1
- [ ] GPIOB, GPIOC...
- [ ] Rever os into_pu...

### Time
- [ ] 

### AFIO
    Pensar como abstrair isso...
- [ ] remap

### PWM
- [ ] Pwm
- [ ] PwmPin
...

### Exception
- [ ] Systick

